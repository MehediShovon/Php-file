<?php
	session_start();
	define("HOST","localhost");
	define("USER","root");
	define("PASS","");
	define("DB","personal_login");

	$db = new mysqli(HOST,USER,PASS,DB);

	if($db){
		// echo "<script>alert('Database Connected');</script>";
	}
	else{
		echo "script>alert('No Database Connected');</script>";
	}
?>